import { Component, OnInit } from '@angular/core';
import { AddGstComponent } from 'app/add-gst/add-gst.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import { ConfirmationDialogService } from '../confirmaion-dialog/confirmation-dialog.service';

@Component({
    selector: 'app-report',
    templateUrl: './report.component.html',
    styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit {
    constructor() { }
    ngOnInit() {

    }
}

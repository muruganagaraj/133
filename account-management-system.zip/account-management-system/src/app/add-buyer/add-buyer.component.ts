import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DialogData } from 'app/buyer-detail/buyer-detail.component';
import { Viewmodel } from './add-buyer.viewmodel';
import { TextPairHelperService } from '../services/text-pair-helper.service';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-add-buyer',
  templateUrl: './add-buyer.component.html',
  styleUrls: ['./add-buyer.component.scss']
})
export class AddBuyerComponent implements OnInit {
  vm: Viewmodel = {};
  ddvalue: TextPair[] = [];
  constructor(
    public dialogRef: MatDialogRef<AddBuyerComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private textPairHelperService: TextPairHelperService,
    private http: HttpClient) {

  }

  ngOnInit() {
    const endpoint = 'https://6d73py636l.execute-api.us-east-1.amazonaws.com/default/EDU_G_GetAll';
    return this.http.get(endpoint).subscribe(
      data => {
        this.getdata(data);
        if (this.dialogRef.componentInstance.data) {
          this.vm = this.convertVotoVM(this.dialogRef.componentInstance.data);
        } else {
          this.vm = {};
        }
      }
    )
  }

  getdata(data: any): any {
    this.ddvalue = this.textPairHelperService.createGSTTextPair(data);
  }

  convertVotoVM(data: any): Viewmodel {
    let modaldata: Viewmodel = {};
    modaldata.BuyerId = data.item.BuyerId;
    modaldata.BuyerCode = data.item.BuyerCode;
    modaldata.GSTId = data.item.GSTId;
    modaldata.Address = data.item.Address;
    modaldata.ContactNo = data.item.ContactNo;
    modaldata.Name = data.item.Name;
    return modaldata;
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  onSubmitClick(): void {
    let headers: HttpHeaders = new HttpHeaders();
    headers.append('Content-Type', 'text/plain');
    headers.append('Access-Control-Allow-Origin', '*');
    headers.append('Access-Control-Allow-Methods', 'GET, POST,OPTIONS');
    headers.append('Accept', 'application/json');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    if (this.vm && this.vm.BuyerId) {
      let options = { headers: headers, withCredentials: false };
      let jsonSaveObject = {
        BuyerId: this.vm.BuyerId,
        BuyerCode: this.vm.BuyerCode,
        GSTId: this.vm.GSTId,
        Name: this.vm.Name,
        ContactNo: this.vm.ContactNo,
        Address: this.vm.Address
      }
      let jsonString = JSON.stringify(jsonSaveObject);
      this.http.post('https://f7hcr8mbee.execute-api.us-east-1.amazonaws.com/default/EDU_B_UpdateById',
        jsonString
        , options).subscribe(result => {
          location.reload();
          var response = result;
        });
    } else {
      let options = { headers: headers, withCredentials: false };
      let jsonSaveObject = {
        BuyerCode: this.vm.BuyerCode,
        GSTId: this.vm.GSTId,
        Name: this.vm.Name,
        ContactNo: this.vm.ContactNo,
        Address: this.vm.Address
      }
      let jsonString = JSON.stringify(jsonSaveObject);
      this.http.post('https://6vpxfu165k.execute-api.us-east-1.amazonaws.com/default/GST_B_Add',
        jsonString
        , options).subscribe(result => {
          location.reload();
          var response = result;
        });
      console.log("Save api call");
    }
  }
}
